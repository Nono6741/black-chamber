extends Node3D
# BLACK CHAMBER: HISTORICAL ROULETTE
# Godot 4 prototype. Uses primitive geometry so no external assets are required.
# Controls: WASD, mouse, LMB fire, R reload, ESC release mouse.

const PLAYER_HP := 100.0
const WEAPON_COUNT := 4
const MOVE_SPEED := 5.0
const MOUSE_SENS := 0.0025

var player: CharacterBody3D
var camera: Camera3D
var gun: MeshInstance3D
var muzzle: Node3D
var enemies: Array[Node3D] = []
var boss: Node3D
var hp := PLAYER_HP
var score := 0
var round_index := 0
var recoil := 0.0
var fire_cooldown := 0.0
var reload_timer := 0.0
var is_reloading := false
var status_text := ""
var weapons: Array[Weapon] = []
var weapon_index := 0
var current_weapon: Weapon
var last_shot_time := 0.0
var rng := RandomNumberGenerator.new()
var hud: Label
var crosshair: Label
var vignette: ColorRect

# Historical factions are presented as fictionalized combatants inspired by uniforms/eras.
# Boss names are historical figures used in a supernatural arcade setting.
var rounds = [
	{"faction":"ROMAN LEGION","color":Color(0.32,0.28,0.20),"boss":"CAESAR","boss_hp":260.0,"theme":"ASHEN FORUM"},
	{"faction":"VIKING WAR BAND","color":Color(0.18,0.20,0.22),"boss":"THE JARL","boss_hp":310.0,"theme":"FROZEN HALL"},
	{"faction":"MEDIEVAL KNIGHTS","color":Color(0.20,0.20,0.23),"boss":"THE BLACK KNIGHT","boss_hp":360.0,"theme":"CATHEDRAL OF IRON"},
	{"faction":"SAMURAI CLAN","color":Color(0.25,0.06,0.08),"boss":"THE SHOGUN","boss_hp":410.0,"theme":"BLOOD MOON DOJO"},
	{"faction":"AZTEC WARRIORS","color":Color(0.16,0.25,0.12),"boss":"THE EAGLE LORD","boss_hp":460.0,"theme":"TEMPLE OF SMOKE"},
	{"faction":"NAPOLEONIC INFANTRY","color":Color(0.10,0.15,0.28),"boss":"NAPOLEON","boss_hp":520.0,"theme":"WINTER COMMAND"},
	{"faction":"OTTOMAN JANISSARIES","color":Color(0.25,0.12,0.06),"boss":"THE GRAND VEZIR","boss_hp":580.0,"theme":"EMBERS OF THE PALACE"},
	{"faction":"AMERICAN REVOLUTIONARYS","color":Color(0.12,0.18,0.25),"boss":"THE GENERAL","boss_hp":650.0,"theme":"MIDNIGHT COLONY"},
	{"faction":"WWI INFANTRY","color":Color(0.18,0.16,0.12),"boss":"THE TRENCH COMMANDER","boss_hp":730.0,"theme":"NO MAN'S LAND"},
	{"faction":"WWII INFANTRY","color":Color(0.16,0.20,0.13),"boss":"THE LAST COMMANDER","boss_hp":850.0,"theme":"THE BLACK BUNKER"}
]

func _ready():
	rng.randomize()
	_setup_weapons()
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	_build_world()
	_build_player()
	_build_hud()
	_start_round()


func _setup_weapons():
	weapons.clear()

	var shotgun = Weapon.new()
	shotgun.weapon_name = "OLD IRON"
	shotgun.magazine_size = 6
	shotgun.reserve_ammo = 30
	shotgun.pellets = 8
	shotgun.damage = 14.0
	shotgun.spread = 0.055
	shotgun.fire_delay = 0.62
	shotgun.reload_time = 1.9
	shotgun.range = 30.0
	shotgun.recoil = 0.18
	shotgun.description = "Heavy spread. Devastating up close."
	weapons.append(shotgun)

	var pistol = Weapon.new()
	pistol.weapon_name = "BLACK JACK"
	pistol.magazine_size = 12
	pistol.reserve_ammo = 72
	pistol.pellets = 1
	pistol.damage = 28.0
	pistol.spread = 0.012
	pistol.fire_delay = 0.24
	pistol.reload_time = 1.25
	pistol.range = 45.0
	pistol.recoil = 0.055
	pistol.description = "Fast sidearm with reliable accuracy."
	weapons.append(pistol)

	var smg = Weapon.new()
	smg.weapon_name = "RATTLER"
	smg.magazine_size = 24
	smg.reserve_ammo = 120
	smg.pellets = 1
	smg.damage = 11.0
	smg.spread = 0.035
	smg.fire_delay = 0.085
	smg.reload_time = 1.7
	smg.automatic = true
	smg.range = 38.0
	smg.recoil = 0.035
	smg.description = "Automatic fire. Eats ammunition."
	weapons.append(smg)

	var rifle = Weapon.new()
	rifle.weapon_name = "LONG SHADOW"
	rifle.magazine_size = 5
	rifle.reserve_ammo = 35
	rifle.pellets = 1
	rifle.damage = 65.0
	rifle.spread = 0.004
	rifle.fire_delay = 0.95
	rifle.reload_time = 2.1
	rifle.range = 75.0
	rifle.recoil = 0.11
	rifle.description = "Slow, precise, brutally powerful."
	weapons.append(rifle)

	for w in weapons:
		w.set_meta("mag",w.magazine_size)
		w.set_meta("reserve",w.reserve_ammo)
	current_weapon = weapons[0]
 
func _build_world():
	var world_env = WorldEnvironment.new()
	var env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.006,0.005,0.008)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.16,0.10,0.13)
	env.ambient_light_energy = 0.22
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world_env.environment = env
	add_child(world_env)

	var floor = _box("Floor", Vector3(24,0.5,24), Vector3(0,-0.25,0), Color(0.035,0.03,0.035))
	var table = _box("BlackTable", Vector3(7,1,4), Vector3(0,1.0,-3), Color(0.025,0.012,0.02))
	var back = _box("BackWall", Vector3(24,8,0.4), Vector3(0,4,-11), Color(0.025,0.02,0.025))
	var left = _box("LeftWall", Vector3(0.4,8,24), Vector3(-12,4,0), Color(0.02,0.018,0.025))
	var right = _box("RightWall", Vector3(0.4,8,24), Vector3(12,4,0), Color(0.02,0.018,0.025))

	# Hanging lamps create the smoky gambling-room silhouette.
	for z in [-7.0,-2.0,3.0]:
		var lamp = OmniLight3D.new()
		lamp.position = Vector3(0,5.5,z)
		lamp.light_color = Color(0.72,0.40,0.24)
		lamp.light_energy = 1.4
		lamp.omni_range = 7.0
		add_child(lamp)

func _build_player():
	player = CharacterBody3D.new()
	player.name = "Player"
	player.position = Vector3(0,1.1,7)
	add_child(player)

	var shape = CollisionShape3D.new()
	var capsule = CapsuleShape3D.new()
	capsule.radius = 0.35
	capsule.height = 1.7
	shape.shape = capsule
	shape.position.y = 0.85
	player.add_child(shape)

	camera = Camera3D.new()
	camera.position = Vector3(0,0.65,0)
	camera.current = true
	player.add_child(camera)

	gun = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = Vector3(0.22,0.18,0.85)
	gun.mesh = box
	gun.position = Vector3(0.34,-0.28,-0.75)
	gun.scale = Vector3(1.0, 1.0, 1.0)
	gun.rotation_degrees = Vector3(-5,0,0)
	gun.material_override = _mat(Color(0.045,0.04,0.04), 0.7)
	camera.add_child(gun)

	muzzle = Node3D.new()
	muzzle.position = Vector3(0,-0.02,-1.2)
	camera.add_child(muzzle)

func _build_hud():
	hud = Label.new()
	hud.position = Vector2(28,25)
	hud.add_theme_font_size_override("font_size",22)
	add_child(hud)

	crosshair = Label.new()
	crosshair.text = "+"
	crosshair.position = Vector2(638,345)
	crosshair.add_theme_font_size_override("font_size",28)
	add_child(crosshair)

	vignette = ColorRect.new()
	vignette.color = Color(0.10,0.0,0.0,0.0)
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vignette.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(vignette)

func _start_round():
	var data = rounds[round_index]
	status_text = data.faction + "  //  ENTER THE BLACK CHAMBER"
	message_timer = 2.5
	for e in enemies:
		if is_instance_valid(e): e.queue_free()
	enemies.clear()
	boss = null

	for i in range(7 + round_index * 2):
		_spawn_enemy(data.color, i)

	# Campaign title card.
	status_text = "STAGE " + str(round_index+1) + "/10  //  " + data.theme
	message_timer = 3.5

func _spawn_enemy(color:Color, index:int):
	var e = CharacterBody3D.new()
	e.name = "HistoricalSoldier"
	e.set_meta("faction", rounds[round_index]["faction"])
	var angle = rng.randf_range(0, TAU)
	var radius = rng.randf_range(6.0, 9.5)
	e.position = Vector3(cos(angle)*radius, 0, sin(angle)*radius)
	e.set_meta("hp", 55.0 + round_index*12)
	e.set_meta("speed", 0.7 + round_index*0.12)
	e.set_meta("damage_timer", 0.0)
	e.set_meta("anim_time", rng.randf_range(0.0, 10.0))
	e.set_meta("twitch", rng.randf_range(1.0, 4.0))
	e.set_meta("base_y", 0.0)
	e.set_meta("crawl_phase", rng.randf_range(0.0, TAU))
	e.set_meta("limp_phase", rng.randf_range(0.0, TAU))
	e.set_meta("shake_phase", rng.randf_range(0.0, TAU))
	add_child(e)

	var body = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = Vector3(0.7,1.6,0.45)
	body.mesh = mesh
	body.position.y = 0.8
	body.material_override = _mat(color,0.25)
	body.set_meta("is_enemy_body", true)
	e.add_child(body)

	# Separate head and arms let each faction get a distinct animation silhouette.
	var head = MeshInstance3D.new()
	var head_mesh = SphereMesh.new()
	head_mesh.radius = 0.28
	head_mesh.height = 0.56
	head.mesh = head_mesh
	head.position = Vector3(0, 1.82, 0)
	head.material_override = _mat(color.darkened(0.18),0.2)
	head.set_meta("anim_part", "head")
	e.add_child(head)

	for side in [-1.0, 1.0]:
		var arm = MeshInstance3D.new()
		var arm_mesh = BoxMesh.new()
		arm_mesh.size = Vector3(0.16,0.85,0.16)
		arm.mesh = arm_mesh
		arm.position = Vector3(side*0.48, 1.0, 0)
		arm.rotation.z = side*0.12
		arm.material_override = _mat(color.darkened(0.1),0.15)
		arm.set_meta("anim_part", "arm")
		e.add_child(arm)

	# Tiny glowing eyes make the silhouettes readable in the darkness.
	for eye_x in [-0.13, 0.13]:
		var eye = MeshInstance3D.new()
		var eye_mesh = SphereMesh.new()
		eye_mesh.radius = 0.045
		eye_mesh.height = 0.09
		eye.mesh = eye_mesh
		eye.position = Vector3(eye_x, 1.25, -0.24)
		eye.material_override = _mat(Color(0.65,0.025,0.015),0.0)
		e.add_child(eye)

	var col = CollisionShape3D.new()
	var shape = CapsuleShape3D.new()
	shape.radius = 0.38
	shape.height = 1.6
	col.shape = shape
	col.position.y = 0.8
	e.add_child(col)

	enemies.append(e)

func _spawn_boss():
	var data = rounds[round_index]
	var e = CharacterBody3D.new()
	e.name = "BOSS_" + data.boss
	e.position = Vector3(0,0,-7)
	e.set_meta("hp", data.boss_hp)
	e.set_meta("speed", 1.0 + round_index*0.15)
	e.set_meta("damage_timer", 0.0)
	add_child(e)
	boss = e

	var body = MeshInstance3D.new()
	var mesh = CylinderMesh.new()
	mesh.top_radius = 0.55
	mesh.bottom_radius = 0.75
	mesh.height = 2.6
	body.mesh = mesh
	body.position.y = 1.3
	body.material_override = _mat(Color(0.10,0.025,0.025),0.18)
	body.set_meta("is_boss_body", true)
	e.add_child(body)

	for eye_x in [-0.22, 0.22]:
		var eye = MeshInstance3D.new()
		var eye_mesh = SphereMesh.new()
		eye_mesh.radius = 0.07
		eye_mesh.height = 0.14
		eye.mesh = eye_mesh
		eye.position = Vector3(eye_x, 1.65, -0.67)
		eye.material_override = _mat(Color(0.9,0.04,0.01),0.0)
		e.add_child(eye)

	var crown = MeshInstance3D.new()
	var cm = PrismMesh.new()
	cm.size = Vector3(1.3,0.35,1.3)
	crown.mesh = cm
	crown.position.y = 2.9
	crown.material_override = _mat(Color(0.28,0.18,0.05),0.35)
	e.add_child(crown)

	var col = CollisionShape3D.new()
	var shape = CapsuleShape3D.new()
	shape.radius = 0.75
	shape.height = 2.6
	col.shape = shape
	col.position.y = 1.3
	e.add_child(col)

	status_text = "BOSS: " + data.boss + "  //  " + str(int(data.boss_hp)) + " HP"
	message_timer = 3.0

func _physics_process(delta):
	if not player: return
	fire_cooldown = max(0.0, fire_cooldown-delta)
	recoil = lerp(recoil,0.0,delta*9.0)
	message_timer = max(0.0,message_timer-delta)

	_move_player(delta)
	_update_enemies(delta)
	_update_hud()

	if Input.is_action_just_pressed("fire") or (current_weapon.automatic and Input.is_action_pressed("fire")):
		_fire()
	if Input.is_action_just_pressed("reload"):
		_reload()
	if Input.is_key_pressed(KEY_1):
		_switch_weapon(0)
	if Input.is_key_pressed(KEY_2):
		_switch_weapon(1)
	if Input.is_key_pressed(KEY_3):
		_switch_weapon(2)
	if Input.is_key_pressed(KEY_4):
		_switch_weapon(3)
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_WHEEL_UP):
		_switch_weapon((weapon_index + WEAPON_COUNT - 1) % WEAPON_COUNT)
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_WHEEL_DOWN):
		_switch_weapon((weapon_index + 1) % WEAPON_COUNT)
	if Input.is_key_pressed(KEY_ESCAPE):
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)

	if Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
		var center = get_viewport().get_visible_rect().size/2
		Input.warp_mouse(center)

func _unhandled_input(event):
	if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
		player.rotate_y(-event.relative.x*MOUSE_SENS)
		camera.rotation.x = clamp(camera.rotation.x-event.relative.y*MOUSE_SENS,-1.35,1.35)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _move_player(delta):
	var input = Input.get_vector("ui_left","ui_right","ui_up","ui_down")
	var dir = (player.transform.basis * Vector3(input.x,0,input.y)).normalized()
	if Input.is_key_pressed(KEY_W): dir -= player.global_transform.basis.z
	if Input.is_key_pressed(KEY_S): dir += player.global_transform.basis.z
	if Input.is_key_pressed(KEY_A): dir -= player.global_transform.basis.x
	if Input.is_key_pressed(KEY_D): dir += player.global_transform.basis.x
	dir.y = 0
	dir = dir.normalized()
	player.velocity.x = dir.x*MOVE_SPEED
	player.velocity.z = dir.z*MOVE_SPEED
	player.velocity.y = 0
	player.move_and_slide()
	player.position.x = clamp(player.position.x,-10.5,10.5)
	player.position.z = clamp(player.position.z,-9.5,10.5)

func _fire():
	if is_reloading or fire_cooldown > 0:
		return
	if current_weapon.magazine_size <= 0:
		return
	if current_weapon_mag() <= 0:
		status_text = "CLICK  //  EMPTY  //  PRESS R"
		return

	consume_round()
	fire_cooldown = current_weapon.fire_delay
	recoil = current_weapon.recoil
	gun.position.z = -0.55
	gun.rotation.x = deg_to_rad(-10.0)

	for i in current_weapon.pellets:
		var origin = camera.global_position
		var forward = -camera.global_transform.basis.z
		var spread = Vector3(
			rng.randfn(0,current_weapon.spread),
			rng.randfn(0,current_weapon.spread),
			rng.randfn(0,current_weapon.spread*0.65)
		)
		var dir = (forward + spread).normalized()
		var query = PhysicsRayQueryParameters3D.create(origin, origin + dir*current_weapon.range)
		query.exclude = [player]
		var hit = get_world_3d().direct_space_state.intersect_ray(query)
		if hit:
			var target = hit.collider
			if target and target.get_parent() and target.get_parent().has_meta("hp"):
				target = target.get_parent()
			if target and target.has_meta("hp"):
				target.set_meta("hp", float(target.get_meta("hp"))-current_weapon.damage)
				if target == boss:
					status_text = "BOSS HIT  //  " + str(max(0,int(target.get_meta("hp")))) + " HP"
				_check_death(target)

	if current_weapon_mag() == 0:
		status_text = current_weapon.weapon_name + " EMPTY  //  PRESS R"

func current_weapon_mag() -> int:
	return int(current_weapon.get_meta("mag", current_weapon.magazine_size))

func current_weapon_reserve() -> int:
	return int(current_weapon.get_meta("reserve", current_weapon.reserve_ammo))

func consume_round():
	current_weapon.set_meta("mag", current_weapon_mag()-1)

func _reload():
	if is_reloading:
		return
	if current_weapon_mag() >= current_weapon.magazine_size:
		status_text = "MAGAZINE FULL"
		return
	if current_weapon_reserve() <= 0:
		status_text = "NO RESERVE AMMO"
		return
	is_reloading = true
	reload_timer = current_weapon.reload_time
	status_text = "RELOADING " + current_weapon.weapon_name + "..."

func _finish_reload():
	is_reloading = false
	var needed = current_weapon.magazine_size-current_weapon_mag()
	var loaded = min(needed,current_weapon_reserve())
	current_weapon.set_meta("mag",current_weapon_mag()+loaded)
	current_weapon.set_meta("reserve",current_weapon_reserve()-loaded)
	status_text = "READY  //  " + current_weapon.weapon_name

func _switch_weapon(index:int):
	if index < 0 or index >= weapons.size() or index == weapon_index:
		return
	if is_reloading:
		is_reloading = false
		reload_timer = 0
	weapon_index = index
	current_weapon = weapons[weapon_index]
	status_text = "EQUIPPED  //  " + current_weapon.weapon_name
	gun.scale = Vector3(1.0 + index*0.06, 1.0, 1.0 + index*0.08)

func _check_death(target):
	if float(target.get_meta("hp")) > 0: return
	if target == boss:
		score += 1000
		round_index += 1
		if round_index >= rounds.size():
			status_text = "10 ARMIES DEFEATED  //  THE CHAMBER IS SILENT  //  YOU WIN"
			message_timer = 9999.0
			set_physics_process(false)
		else:
			status_text = "BOSS DOWN  //  NEXT TABLE"
			_start_round()
	else:
		score += 100
		enemies.erase(target)
		target.queue_free()
		if enemies.is_empty() and boss == null:
			_spawn_boss()

func _update_enemies(delta):
	for e in enemies.duplicate():
		if not is_instance_valid(e): continue
		_chase(e,delta,1.0)
	if boss and is_instance_valid(boss):
		_chase(boss,delta,0.55)

func _chase(e,delta,mult):
	var to_player = player.global_position-e.global_position
	to_player.y = 0
	var d = to_player.length()

	var t = float(e.get_meta("anim_time")) + delta
	e.set_meta("anim_time", t)

	var faction = str(e.get_meta("faction")) if e.has_meta("faction") else "UNKNOWN"
	var anim_parts = []
	for child in e.get_children():
		if child.has_meta("anim_part"):
			anim_parts.append(child)

	# ============================================================
	# UNIQUE FACTION MOVEMENT
	# ============================================================
	# Romans: unnervingly disciplined marching with synchronized arms.
	if faction == "ROMAN LEGION":
		var march = sin(t*7.0)
		e.rotation.z = lerp(e.rotation.z, march*0.045, delta*8.0)
		for part in anim_parts:
			if part.get_meta("anim_part") == "arm":
				var side = sign(part.position.x)
				part.rotation.z = side*(0.15 + march*0.22)
			elif part.get_meta("anim_part") == "head":
				part.rotation.y = sin(t*2.0)*0.06
		e.position.y = sin(t*7.0)*0.025

	# Napoleonic troops: one leg appears damaged, producing a pronounced limp.
	elif faction == "NAPOLEONIC INFANTRY":
		var limp = abs(sin(t*4.5))
		e.rotation.z = lerp(e.rotation.z, sin(t*4.5)*0.08, delta*5.0)
		e.position.y = sin(t*4.5)*0.045
		for part in anim_parts:
			if part.get_meta("anim_part") == "head":
				part.rotation.z = sin(t*4.5)*0.12
			elif part.get_meta("anim_part") == "arm":
				part.rotation.x = sin(t*4.5 + part.position.x)*0.18

	# Samurai: crouched, low crawl when close, with sudden upward snaps.
	elif faction == "SAMURAI CLAN":
		var crawl = sin(t*5.5)
		var close_crawl = clamp((5.0-d)/3.0,0.0,1.0)
		var target_y = -0.42*close_crawl + crawl*0.035
		e.position.y = lerp(e.position.y,target_y,delta*7.0)
		e.rotation.x = lerp(e.rotation.x, -0.18*close_crawl + sin(t*8.0)*0.06, delta*6.0)
		e.rotation.z = lerp(e.rotation.z, sin(t*5.5)*0.12, delta*6.0)
		for part in anim_parts:
			if part.get_meta("anim_part") == "arm":
				part.rotation.x = crawl*0.55
				part.rotation.z += crawl*0.15
			elif part.get_meta("anim_part") == "head":
				part.rotation.z = sin(t*9.0)*0.15

	# WWII infantry: violent tremors, head jerks, and abrupt direction changes.
	elif faction == "VIKING WAR BAND":
		var stomp = sin(t*4.0)
		e.rotation.z = lerp(e.rotation.z, stomp*0.11, delta*7.0)
		e.position.y = sin(t*4.0)*0.06
		for part in anim_parts:
			if part.get_meta("anim_part") == "arm":
				part.rotation.x = sin(t*4.0 + part.position.x)*0.42
			elif part.get_meta("anim_part") == "head":
				part.rotation.y = sin(t*3.0)*0.12

	elif faction == "MEDIEVAL KNIGHTS":
		var heavy = sin(t*3.0)
		e.rotation.x = lerp(e.rotation.x, heavy*0.035, delta*5.0)
		e.position.y = abs(sin(t*3.0))*0.055
		for part in anim_parts:
			if part.get_meta("anim_part") == "head":
				part.rotation.z = sin(t*2.0)*0.18

	elif faction == "AZTEC WARRIORS":
		var ritual = sin(t*6.0)
		e.rotation.y += delta*0.35
		e.rotation.z = lerp(e.rotation.z, ritual*0.16, delta*8.0)
		for part in anim_parts:
			if part.get_meta("anim_part") == "arm":
				part.rotation.x = ritual*0.5

	elif faction == "OTTOMAN JANISSARIES":
		var sway = sin(t*2.5)
		e.rotation.z = lerp(e.rotation.z, sway*0.10, delta*6.0)
		for part in anim_parts:
			if part.get_meta("anim_part") == "head":
				part.rotation.y = sin(t*4.0)*0.14

	elif faction == "AMERICAN REVOLUTIONARYS":
		var march = sin(t*5.0)
		e.rotation.z = lerp(e.rotation.z, march*0.06, delta*7.0)
		e.position.y = sin(t*5.0)*0.03

	elif faction == "WWI INFANTRY":
		var shellshock = sin(t*18.0)
		e.rotation.z = lerp(e.rotation.z, shellshock*0.12, delta*12.0)
		e.rotation.x = lerp(e.rotation.x, sin(t*14.0)*0.08, delta*12.0)
		for part in anim_parts:
			if part.get_meta("anim_part") == "head":
				part.rotation.z = sin(t*22.0)*0.22

	elif faction == "WWII INFANTRY":
		var shake = sin(t*23.0)
		var tremor = sin(t*31.0)*0.07
		e.rotation.z = lerp(e.rotation.z, shake*0.09 + tremor, delta*15.0)
		e.rotation.x = lerp(e.rotation.x, sin(t*17.0)*0.055, delta*15.0)
		e.position.y = sin(t*25.0)*0.035
		for part in anim_parts:
			if part.get_meta("anim_part") == "head":
				part.rotation.y = sin(t*29.0)*0.28
				part.rotation.z = sin(t*37.0)*0.18
			elif part.get_meta("anim_part") == "arm":
				part.rotation.x = sin(t*21.0 + part.position.x)*0.32

	else:
		e.rotation.z = sin(t*2.0)*0.08

	# ============================================================
	# MOVEMENT BEHAVIOR
	# ============================================================
	if d > 4.0:
		var direction = to_player.normalized()
		var speed = float(e.get_meta("speed"))*mult

		# Different factions approach differently.
		if faction == "SAMURAI CLAN":
			# Short bursts instead of a steady walk.
			speed *= 1.0 + max(0.0,sin(t*2.7))*0.8
		elif faction == "NAPOLEONIC INFANTRY":
			# Limping soldiers are slower.
			speed *= 0.72
		elif faction == "WWII INFANTRY":
			# Unpredictable micro-stutters.
			speed *= 0.65 + abs(sin(t*8.0))*0.75
		elif faction == "VIKING WAR BAND":
			speed *= 1.18
		elif faction == "MEDIEVAL KNIGHTS":
			speed *= 0.65
		elif faction == "AZTEC WARRIORS":
			speed *= 0.9 + abs(sin(t*5.0))*0.65
		elif faction == "OTTOMAN JANISSARIES":
			speed *= 0.82
		elif faction == "AMERICAN REVOLUTIONARYS":
			speed *= 0.92
		elif faction == "WWI INFANTRY":
			speed *= 0.72 + abs(sin(t*11.0))*0.65


		e.velocity = direction*speed
		e.move_and_slide()

	elif d > 1.8:
		var lurch = to_player.normalized()
		var lurch_speed = float(e.get_meta("speed"))*(mult*1.8)

		if faction == "SAMURAI CLAN":
			lurch_speed *= 1.5
		elif faction == "WWII INFANTRY":
			lurch_speed *= 0.8

		e.velocity = lurch*lurch_speed
		e.move_and_slide()

	else:
		e.velocity = Vector3.ZERO

		# Every faction has a different close attack pose.
		if faction == "ROMAN LEGION":
			e.rotation.x = lerp(e.rotation.x,-0.10,delta*12.0)
		elif faction == "NAPOLEONIC INFANTRY":
			e.rotation.z = lerp(e.rotation.z,0.22,delta*10.0)
		elif faction == "SAMURAI CLAN":
			e.rotation.x = lerp(e.rotation.x,-0.5,delta*14.0)
		elif faction == "WWII INFANTRY":
			e.rotation.x = lerp(e.rotation.x,sin(t*30.0)*0.2,delta*18.0)

		var timer = float(e.get_meta("damage_timer"))-delta
		if timer <= 0:
			hp -= 8.0 if e == boss else 4.0
			timer = 1.0
		e.set_meta("damage_timer",timer)
		vignette.color.a = clamp((100.0-hp)/500.0,0.0,0.32)

		if hp <= 0:
			hp = PLAYER_HP
			for w in weapons:
				w["ammo"] = int(w["mag"])
			shells = int(weapons[current_weapon]["ammo"])
			player.position = Vector3(0,1.1,7)
			status_text = "THE HOUSE COLLECTS  //  RESET"

func _update_hud():
	var faction = rounds[round_index].faction if round_index < rounds.size() else "VICTORY"
	var boss_text = ""
	if boss and is_instance_valid(boss):
		boss_text = "\nBOSS: " + str(boss.name).replace("BOSS_","") + "  HP " + str(max(0,int(boss.get_meta("hp"))))
	var weapon_text = "\n[" + str(weapon_index+1) + "] " + current_weapon.weapon_name
	weapon_text += "    AMMO " + str(current_weapon_mag()) + "/" + str(current_weapon_reserve())
	weapon_text += "    " + ("RELOADING..." if is_reloading else current_weapon.description)
	hud.text = stage_text + "\n" + faction + "\nHP " + str(int(hp)) + "     SCORE " + str(score) + weapon_text + boss_text
	if message_timer > 0:
		hud.text += "\n\n" + status_text

func _box(n:String,size:Vector3,pos:Vector3,color:Color):
	var m = MeshInstance3D.new()
	m.name = n
	var mesh = BoxMesh.new()
	mesh.size = size
	m.mesh = mesh
	m.position = pos
	m.material_override = _mat(color,0.8)
	add_child(m)
	return m

func _mat(color:Color,metal:float):
	var mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.metallic = metal
	mat.roughness = 0.42
	return mat
