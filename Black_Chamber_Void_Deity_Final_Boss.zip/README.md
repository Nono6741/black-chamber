# Black Chamber: Historical Roulette

A Godot 4 first-person retro horror shooter prototype.

## 10-Stage Campaign
1. Roman Legion - Ashen Forum - Boss: Caesar
2. Viking War Band - Frozen Hall - Boss: The Jarl
3. Medieval Knights - Cathedral of Iron - Boss: The Black Knight
4. Samurai Clan - Blood Moon Dojo - Boss: The Shogun
5. Aztec Warriors - Temple of Smoke - Boss: The Eagle Lord
6. Napoleonic Infantry - Winter Command - Boss: Napoleon
7. Ottoman Janissaries - Embers of the Palace - Boss: The Grand Vizier
8. American Revolutionaries - Midnight Colony - Boss: The General
9. WWI Infantry - No Man's Land - Boss: The Trench Commander
10. WWII Infantry - The Black Altar - Boss: **The Void Deity**

## Final Boss
The final encounter abandons the historical theme and becomes supernatural. The Void Deity:
- Has 1,600 HP
- Floats around the arena
- Has six glowing eyes and orbiting rings
- Uses three escalating phases
- Becomes faster and more aggressive as its health falls
- Creates a dark supernatural endgame atmosphere

## Controls
WASD = move
Mouse = look
Left mouse = fire
R = reload
1 / 2 / 3 = switch weapons
Mouse wheel = cycle weapons
ESC = release mouse
