class_name Weapon
extends Resource

@export var weapon_name: String = "Weapon"
@export var magazine_size: int = 6
@export var reserve_ammo: int = 24
@export var pellets: int = 1
@export var damage: float = 20.0
@export var spread: float = 0.01
@export var fire_delay: float = 0.25
@export var reload_time: float = 1.5
@export var automatic: bool = false
@export var range: float = 40.0
@export var recoil: float = 0.08
@export var hitscan: bool = true
@export var description: String = ""

func clone():
	var w = Weapon.new()
	w.weapon_name = weapon_name
	w.magazine_size = magazine_size
	w.reserve_ammo = reserve_ammo
	w.pellets = pellets
	w.damage = damage
	w.spread = spread
	w.fire_delay = fire_delay
	w.reload_time = reload_time
	w.automatic = automatic
	w.range = range
	w.recoil = recoil
	w.hitscan = hitscan
	w.description = description
	return w
